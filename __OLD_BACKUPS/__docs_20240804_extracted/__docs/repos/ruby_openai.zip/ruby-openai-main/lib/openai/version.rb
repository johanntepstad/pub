module OpenAI
  VERSION = "7.1.0".freeze
end
