# frozen_string_literal: true

module Weaviate
  VERSION = "0.9.0"
end
