# frozen_string_literal: true

module Weaviate
  class Error < StandardError
  end
end
