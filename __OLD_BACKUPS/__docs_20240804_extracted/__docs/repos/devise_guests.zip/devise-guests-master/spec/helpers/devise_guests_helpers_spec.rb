require "spec_helper"

describe "devise guest helpers", type: :helper do
end
