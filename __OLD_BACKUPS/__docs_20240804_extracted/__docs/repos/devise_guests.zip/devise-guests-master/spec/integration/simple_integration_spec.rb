require "spec_helper"

describe "Simple Integration", type: :request do
  it "should work" do
  end
end
