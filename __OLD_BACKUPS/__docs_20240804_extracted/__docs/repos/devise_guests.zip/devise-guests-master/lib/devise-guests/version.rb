module DeviseGuests
  VERSION = "0.8.3"
end
