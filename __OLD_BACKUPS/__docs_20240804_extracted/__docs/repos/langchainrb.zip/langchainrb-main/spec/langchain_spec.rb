# frozen_string_literal: true

RSpec.describe Langchain do
  it "has a version number" do
    expect(Langchain::VERSION).not_to be nil
  end
end
