module Langchain
  module Prompt
    include Loading
  end
end
