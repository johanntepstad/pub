# frozen_string_literal: true

module Langchain
  VERSION = "0.14.0"
end
