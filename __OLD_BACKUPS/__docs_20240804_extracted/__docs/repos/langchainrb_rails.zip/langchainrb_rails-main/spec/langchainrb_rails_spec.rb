# frozen_string_literal: true

RSpec.describe LangchainrbRails do
  it "has a version number" do
    expect(LangchainrbRails::VERSION).not_to be nil
  end
end
