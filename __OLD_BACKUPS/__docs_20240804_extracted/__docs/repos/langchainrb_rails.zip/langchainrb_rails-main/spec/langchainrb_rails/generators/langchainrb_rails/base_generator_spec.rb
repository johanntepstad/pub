# frozen_string_literal: true

RSpec.describe LangchainrbRails::Generators::BaseGenerator, type: :generator do
end
