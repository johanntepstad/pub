# frozen_string_literal: true

module LangchainrbRails
  VERSION = "0.1.11"
end
