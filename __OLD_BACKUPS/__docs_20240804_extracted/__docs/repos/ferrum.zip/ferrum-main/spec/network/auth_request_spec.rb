# frozen_string_literal: true

describe Ferrum::Network::AuthRequest do
  skip
end
