# frozen_string_literal: true

describe Ferrum::Network::InterceptedRequest do
  skip
end
