# frozen_string_literal: true

module Ferrum
  VERSION = "0.15"
end
