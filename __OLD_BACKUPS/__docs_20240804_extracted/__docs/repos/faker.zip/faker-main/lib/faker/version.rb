# frozen_string_literal: true

module Faker # :nodoc:
  VERSION = '3.4.2'
end
