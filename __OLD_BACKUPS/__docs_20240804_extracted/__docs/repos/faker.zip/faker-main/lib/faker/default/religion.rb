# frozen_string_literal: true

module Faker
  module Religion
  end
end
