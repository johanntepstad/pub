# Faker::Blockchain::Ethereum

Available since version 1.9.0.

```ruby
Faker::Blockchain::Ethereum.address #=> "0xd392b0c0500700d02d27ab30805ec80ddd3320ff"
```
