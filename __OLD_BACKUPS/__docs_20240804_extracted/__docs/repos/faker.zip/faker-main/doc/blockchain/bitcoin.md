# Faker::Blockchain::Bitcoin

```ruby
Faker::Blockchain::Bitcoin.address #=> "1HUoGjmgChmnxxYhz87YytV4gVjfPaExmh"

Faker::Blockchain::Bitcoin.testnet_address #=> "msHGunDvoEwmVFXvd2Bub1SNw5RP1YHJaf"
```
