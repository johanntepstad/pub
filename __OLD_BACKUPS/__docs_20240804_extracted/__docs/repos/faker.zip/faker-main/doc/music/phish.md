# Faker::Music::Phish

```ruby
Faker::Music::Phish.album #=> "Fuego"

Faker::Music::Phish.musician #=> "Trey Anastasio"

Faker::Music::Phish.song #=> "Tweezer"
```
