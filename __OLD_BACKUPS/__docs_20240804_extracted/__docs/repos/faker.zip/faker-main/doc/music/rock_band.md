# Faker::Music::RockBand

```ruby
Faker::Music::RockBand.name #=> "Led Zeppelin"

Faker::Music::RockBand.song #=> "Dream On"
```
