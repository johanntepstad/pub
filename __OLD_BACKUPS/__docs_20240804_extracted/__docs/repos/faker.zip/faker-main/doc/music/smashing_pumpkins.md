# Faker::Music::SmashingPumpkins

```ruby
Faker::Music::SmashingPumpkins.musician #=> "D'arcy Wretsky"

Faker::Music::SmashingPumpkins.album #=> "Mellon Collie and the Infinite Sadness"

Faker::Music::SmashingPumpkins.song #=> "Disarm"

Faker::Music::SmashingPumpkins.lyric #=> "The world is a vampire, sent to drain, secret destroyers, hold you up to the flames"
```
