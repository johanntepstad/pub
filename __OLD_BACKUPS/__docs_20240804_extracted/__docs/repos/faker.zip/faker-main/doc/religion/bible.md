# Faker::Religion::Bible

```ruby
Faker::Religion::Bible.character #=> "Jesus"

Faker::Religion::Bible.location #=> "Nasareth"

Faker::Religion::Bible.quote #=> "Seek first the kingdom of God "
```
