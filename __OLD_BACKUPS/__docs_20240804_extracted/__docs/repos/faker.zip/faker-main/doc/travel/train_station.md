# Faker::Travel::TrainStation

```ruby
Faker::Travel::TrainStation.name(region: 'united_kingdom', type: 'metro') #=> "Brockley"
Faker::Travel::TrainStation.name(type: 'railway') #=> "Düsseldorf Hauptbahnhof"
Faker::Travel::TrainStation.name(region: 'spain') #=> "Santa Eulàlia"
```
