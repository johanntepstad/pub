# Faker::ProgrammingLanguage

```ruby
Faker::ProgrammingLanguage.name #=> "Ruby"

Faker::ProgrammingLanguage.creator #=> "Yukihiro Matsumoto"
```
