# Faker::Educator

Available since version 1.6.4.

```ruby
Faker::Educator.university #=> "Mallowtown Technical College"

Faker::Educator.secondary_school #=> "Iceborough Secondary College"

Faker::Educator.primary_school #=> "Brighthurst Elementary School"

Faker::Educator.degree #=> "Associate Degree in Criminology"

Faker::Educator.course_name #=> "Criminology 101"

Faker::Educator.subject #=> "Criminology"

Faker::Educator.campus #=> "Vertapple Campus"
```
