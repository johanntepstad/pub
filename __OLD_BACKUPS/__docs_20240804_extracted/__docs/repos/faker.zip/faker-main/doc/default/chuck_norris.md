# Faker::ChuckNorris

Available since version 1.6.4.

```ruby
Faker::ChuckNorris.fact #=> "Chuck Norris can solve the Towers of Hanoi in one move."
```
