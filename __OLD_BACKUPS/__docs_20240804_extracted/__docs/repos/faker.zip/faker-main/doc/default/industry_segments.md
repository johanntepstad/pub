# Faker::IndustrySegments

```ruby
Faker::IndustrySegments.industry #=> "Basic Materials"

Faker::IndustrySegments.super_sector #=> "Basic Resources"

Faker::IndustrySegments.sector #=> "Industrial Metals & Mining"

Faker::IndustrySegments.sub_sector #=> "Nonferrous Metals"
```
