# Faker::Team

```ruby
# Random Team Creature
Faker::Team.creature #=> "gooses"

# Random Team Name created from random US State (Faker::Address.state) prepended to a random Team Creature
Faker::Team.name #=> "Oregon vixens"

# Random Team State
Faker::Team.state #=> "Oregon"

# Random Team Sport
Faker::Team.sport #=> "lacrosse"

# Random Team Mascot
Faker::Team.mascot #=> "Hugo"
```
