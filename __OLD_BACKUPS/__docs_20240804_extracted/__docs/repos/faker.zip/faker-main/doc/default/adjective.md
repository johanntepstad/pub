# Faker::Adjective

```ruby
# Random Positive Adjective
Faker::Adjective.positive #=> "Kind"

# Random Negative Adjective
Faker::Adjective.negative #=> "Creepy"
```
