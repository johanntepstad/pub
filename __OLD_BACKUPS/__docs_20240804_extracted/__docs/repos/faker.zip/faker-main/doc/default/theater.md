# Faker::Theater

```ruby
# Produces the name of a musical for an older audience
Faker::Theater.adult_musical #=> "Mamma Mia!"

# Produces the name of a musical for a younger audience
Faker::Theater.kids_musical #=> "Into the Woods JR."

# Produces the name of a play
Faker::Theater.play #=> "The Death of a Salesman"

