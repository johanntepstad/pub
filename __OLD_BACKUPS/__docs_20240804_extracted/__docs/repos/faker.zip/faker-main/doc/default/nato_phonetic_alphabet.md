# Faker::NatoPhoneticAlphabet

Available since version 1.9.0.

```ruby
# A code word from the NATO phonetic alphabet
Faker::NatoPhoneticAlphabet.code_word #=> "Hotel"
```
