# Faker::Subscription

```ruby
Faker::Subscription.plan #=> "Platinum"

Faker::Subscription.status #=> "Active"

Faker::Subscription.payment_method #=> "Paypal"

Faker::Subscription.subscription_term #=> "Annual"

Faker::Subscription.payment_term #=> "Monthly"
```
