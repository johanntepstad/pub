# Faker::Esport

```ruby
# Random player
Faker::Esport.player #=> "Crimsix"

# Random team
Faker::Esport.team #=> "CLG"

# Random league
Faker::Esport.league #=> "IEM"

# Random event
Faker::Esport.event #=> "ESL Cologne"

# Random game
Faker::Esport.game #=> "Dota2"
```