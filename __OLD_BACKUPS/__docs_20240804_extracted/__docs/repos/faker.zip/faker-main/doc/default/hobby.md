# Faker::Hobby

# @faker.version next

```ruby
Faker::Hobby.activity #=> "Cooking"
