# Faker::Job

```ruby
Faker::Job.title #=> "Lead Accounting Associate"

Faker::Job.field #=> "Manufacturing"

Faker::Job.seniority #=> "Lead"

Faker::Job.position #=> "Supervisor"

Faker::Job.key_skill #=> "Teamwork"

Faker::Job.employment_type #=> "Full-time"

Faker::Job.education_level #=> "Bachelor"
```
