# Faker::Books::TheKingkillerChronicle

```ruby
# Random The Kingkiller Chronicle book
Faker::Books::TheKingkillerChronicle.book #=> "The Name of the Wind"

# Random The Kingkiller Chronicle character
Faker::Books::TheKingkillerChronicle.character #=> "Kvothe"

# Random The Kingkiller Chronicle creature
Faker::Books::TheKingkillerChronicle.creature #=> "Scrael"

# Random The Kingkiller Chronicle location
Faker::Books::TheKingkillerChronicle.location #=> "Tarbean"
```
