# Faker::Book

```ruby
# Random Book Title
Faker::Book.title #=> "The Odd Sister"

# Random Author
Faker::Book.author #=> "Alysha Olsen"

# Random Publisher
Faker::Book.publisher #=> "Opus Reader"

# Random Genre
Faker::Book.genre #=> "Mystery"
```
