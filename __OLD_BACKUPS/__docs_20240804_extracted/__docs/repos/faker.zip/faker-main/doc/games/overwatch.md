# Faker::Games::Overwatch

Available since version 1.8.0.

```ruby
Faker::Games::Overwatch.hero #=> "Tracer"

Faker::Games::Overwatch.location #=> "Numbani"

Faker::Games::Overwatch.quote #=> "It's high noon"
```
