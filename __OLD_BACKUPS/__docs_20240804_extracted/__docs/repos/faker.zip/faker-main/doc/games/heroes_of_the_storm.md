# Faker::Games::HeroesOfTheStorm

```ruby
Faker::Games::HeroesOfTheStorm.battleground #=> "Towers of Doom"

Faker::Games::HeroesOfTheStorm.class_name #=> "Support"

Faker::Games::HeroesOfTheStorm.hero #=> "Illidan"

Faker::Games::HeroesOfTheStorm.quote #=> "MEAT!!!"
```
