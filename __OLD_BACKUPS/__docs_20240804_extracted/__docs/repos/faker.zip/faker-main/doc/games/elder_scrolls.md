# Faker::Games::ElderScrolls

```ruby
Faker::Games::ElderScrolls.race #=> Argonian

Faker::Games::ElderScrolls.city #=> Solitude

Faker::Games::ElderScrolls.creature #=> Frost Troll

Faker::Games::ElderScrolls.region #=> Cyrodiil

Faker::Games::ElderScrolls.dragon #=> Blood Dragon

Faker::Games::ElderScrolls.first_name #=> Astrid

Faker::Games::ElderScrolls.last_name #=> Mallory

Faker::Games::ElderScrolls.name #=> Babette Brill

Faker::Games::ElderScrolls.weapon #=> Elven Bow

Faker::Games::ElderScrolls.jewelry #=> "Silver Ruby Ring"
```
