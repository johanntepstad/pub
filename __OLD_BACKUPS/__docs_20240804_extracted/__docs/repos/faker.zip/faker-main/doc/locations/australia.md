# Faker::Locations::Australia

```ruby
Faker::Locations::Australia.location # => "Sydney"

Faker::Locations::Australia.animal # => "Kangaroo"

Faker::Locations::Australia.state # => "New South Wales"
```
