# Faker::JapaneseMedia::FullmetalAchemistBrotherhood

```ruby
Faker::JapaneseMedia::FullmetalAchemistBrotherhood.character #=> "Edward Elric"

Faker::JapaneseMedia::FullmetalAchemistBrotherhood.city #=> "Central City"

Faker::JapaneseMedia::FullmetalAchemistBrotherhood.country #=> "Xing"
```
