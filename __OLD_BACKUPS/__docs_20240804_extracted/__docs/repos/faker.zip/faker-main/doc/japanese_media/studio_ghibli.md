# Faker::JapaneseMedia::StudioGhibli

```ruby
Faker::JapaneseMedia::StudioGhibli.character #=> "Howl Jenkins Pendragon"

Faker::JapaneseMedia::StudioGhibli.quote #=> "Here's another curse for you, may all your bacon burn."

Faker::JapaneseMedia::StudioGhibli.movie #=> "Howl's Moving Castle"
```
