# Faker::JapaneseMedia::OnePiece

```ruby
Faker::JapaneseMedia::OnePiece.character #=> "Monkey D. Luffy"

Faker::JapaneseMedia::OnePiece.sea #=> "East Blue"

Faker::JapaneseMedia::OnePiece.island #=> "Laftel"

Faker::JapaneseMedia::OnePiece.location #=> "Foosha Village"

Faker::JapaneseMedia::OnePiece.quote #=> "ONE PIECE IS REAL!"

Faker::JapaneseMedia::OnePiece.akuma_no_mi #=> "Gomu Gomu no Mi"
```
