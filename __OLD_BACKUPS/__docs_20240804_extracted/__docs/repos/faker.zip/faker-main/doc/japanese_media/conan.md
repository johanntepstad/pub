# Faker::JapaneseMedia::Conan

```ruby
Faker::JapaneseMedia::Conan.character #=> "Conan Edogawa"

Faker::JapaneseMedia::Conan.gadget #=> "Voice-Changing Bowtie"

Faker::JapaneseMedia::Conan.vehicle #=> "Agasa's Volkswagen Beetle"
```
