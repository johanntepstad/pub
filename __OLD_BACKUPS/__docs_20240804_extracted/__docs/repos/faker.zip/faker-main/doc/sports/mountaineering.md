# Faker::Sports::Mountaineering

```ruby
Faker::Sports::Mountaineering.mountaineer #=> "Junko Tabei"
```
