# Faker::Sports::Basketball

```ruby
Faker::Sports::Basketball.team #=> "Golden State Warriors"

Faker::Sports::Basketball.player #=> "LeBron James"

Faker::Sports::Basketball.coach #=> "Gregg Popovich"

Faker::Sports::Basketball.position #=> "Point Guard"
```
