# Faker::Movies::HitchhikersGuideToTheGalaxy

Available since version 1.8.0.

```ruby
Faker::Movies::HitchhikersGuideToTheGalaxy.character #=> "Marvin"

Faker::Movies::HitchhikersGuideToTheGalaxy.location #=> "Arthur Dent's house"

Faker::Movies::HitchhikersGuideToTheGalaxy.marvin_quote #=> "Life? Don't talk to me about life."

Faker::Movies::HitchhikersGuideToTheGalaxy.planet #=> "Magrathea"

Faker::Movies::HitchhikersGuideToTheGalaxy.quote #=> "In the beginning, the Universe was created. This has made a lot of people very angry and been widely regarded as a bad move."

Faker::Movies::HitchhikersGuideToTheGalaxy.specie #=> "Perfectly Normal Beast"

Faker::Movies::HitchhikersGuideToTheGalaxy.starship #=> "Vogon Constructor Fleet"
```
