# Faker::Movies::Avatar

```ruby
Faker::Movies::Avatar.character #=> "Miles Quaritch"

Faker::Movies::Avatar.date #=> "December 18, 2009"

Faker::Movies::Avatar.quote #=> "It is hard to fill a cup that is already full."
```
