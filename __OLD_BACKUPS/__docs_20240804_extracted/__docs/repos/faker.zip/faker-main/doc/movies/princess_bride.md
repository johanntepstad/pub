# Faker::Movies::PrincessBride

Available since version 1.9.0.

```ruby
Faker::Movies::PrincessBride.character #=> "Dread Pirate Roberts"

Faker::Movies::PrincessBride.quote #=> "Hello. My name is Inigo Montoya. You killed my father. Prepare to die!"
```
