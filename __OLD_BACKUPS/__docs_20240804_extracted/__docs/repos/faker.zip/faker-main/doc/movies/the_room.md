# Faker::Movies::TheRoom

```ruby
Faker::Movies::TheRoom.actor #=> "Tommy Wiseau"

Faker::Movies::TheRoom.character #=> "Johnny"

Faker::Movies::TheRoom.location #=> "Johnny's Apartment"

Faker::Movies::TheRoom.quote #=> "A-ha-ha-ha! What a story, Mark!"
```
