# Faker::Movies::Tron

```ruby
Faker::Movies::Tron.character #=> "bit"

Faker::Movies::Tron.game #=> "Space Paranoids"

Faker::Movies::Tron.location #=> "Flynn's Arcade"

Faker::Movies::Tron.program #=> "Clu"

Faker::Movies::Tron.quote #=> "Greetings, Programs!"

Faker::Movies::Tron.quote(character: "mcp") #=> "End of Line."

Faker::Movies::Tron.tagline #=> "The Electronic Gladiator"

Faker::Movies::Tron.user #=> "Alan Bradley"

Faker::Movies::Tron.vehicle #=> "Light Cycle"
```
