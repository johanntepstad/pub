# Faker::Movies::VForVendetta

```ruby
Faker::Movies::VForVendetta.character #=> "V"

Faker::Movies::VForVendetta.speech #=> "Remember, remember, the Fifth of November, the Gunpowder Treason and Plot. I know of no reason why the Gunpowder Treason should ever be forgot..."

Faker::Movies::VForVendetta.quote #=> "People should not be afraid of their governments. Governments should be afraid of their people."
```
