# Faker::TvShows::MichaelScott

Available since version 1.9.0.

```ruby
Faker::TvShows::MichaelScott.quote #=> "I am Beyoncé, always."
```
