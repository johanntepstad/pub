# Faker::TvShows::Simpsons

Available since version 1.8.0.

```ruby
Faker::TvShows::Simpsons.character #=> "Charles Montgomery Burns"

Faker::TvShows::Simpsons.location  #=> "Moe's Tavern"

Faker::TvShows::Simpsons.quote     #=> "It takes two to lie: one to lie and one to listen."
```
