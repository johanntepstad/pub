# Faker::TvShows::HowIMetYourMother

Available since version 1.8.0.

```ruby
Faker::TvShows::HowIMetYourMother.character #=> "Barney Stinson"

Faker::TvShows::HowIMetYourMother.catch_phrase #=> "Legendary"

Faker::TvShows::HowIMetYourMother.high_five #=> "Relapse Five"

Faker::TvShows::HowIMetYourMother.quote #=> "Whenever I’m sad, I stop being sad and be awesome instead."
```
