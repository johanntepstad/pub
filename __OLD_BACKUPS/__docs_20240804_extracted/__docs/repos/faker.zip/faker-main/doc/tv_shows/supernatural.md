# Faker::TvShows::Supernatural

```ruby
Faker::TvShows::Supernatural.character #=> "Sam Winchester"
Faker::TvShows::Supernatural.creature #=> "Vampire"
Faker::TvShows::Supernatural.weapon #=> "Colt"
```
