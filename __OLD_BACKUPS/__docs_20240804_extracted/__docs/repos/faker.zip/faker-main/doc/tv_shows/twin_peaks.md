# Faker::TvShows::TwinPeaks

Available since version 1.7.0.

```ruby
Faker::TvShows::TwinPeaks.character #=> "Dale Cooper"

Faker::TvShows::TwinPeaks.location #=> "Black Lodge"

Faker::TvShows::TwinPeaks.quote #=> "The owls are not what they seem."
```
