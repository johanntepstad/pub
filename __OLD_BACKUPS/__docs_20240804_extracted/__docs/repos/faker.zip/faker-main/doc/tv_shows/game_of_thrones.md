# Faker::TvShows::GameOfThrones

Available since version 1.6.6.

```ruby
Faker::TvShows::GameOfThrones.character #=> "Tyrion Lannister"

Faker::TvShows::GameOfThrones.house #=> "Stark"

Faker::TvShows::GameOfThrones.city #=> "Lannisport"

Faker::TvShows::GameOfThrones.quote #=> "Never forget who you are. The rest of the world won't. Wear it like an armor and it can never be used against you."

Faker::TvShows::GameOfThrones.dragon #=> "Drogon"
```
