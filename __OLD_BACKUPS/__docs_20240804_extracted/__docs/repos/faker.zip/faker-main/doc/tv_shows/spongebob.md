# Faker::TvShows::Spongebob

```ruby
Faker::TvShows::Spongebob.character #=> "Patrick"

Faker::TvShows::Spongebob.quote #=> "I'm ready! I'm ready!"

Faker::TvShows::Spongebob.episode #> "Reef Blower"
```
