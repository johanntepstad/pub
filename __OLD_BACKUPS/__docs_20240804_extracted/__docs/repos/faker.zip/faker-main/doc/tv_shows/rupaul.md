# Faker::TvShows::RuPaul

Available since version 1.8.0.

```ruby
Faker::TvShows::RuPaul.quote #=> "That's Funny, Tell Another One"

Faker::TvShows::RuPaul.queen #=> "Latrice Royale"
```
