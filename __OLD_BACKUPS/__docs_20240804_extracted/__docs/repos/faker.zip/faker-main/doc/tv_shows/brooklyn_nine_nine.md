# Faker::TvShows::BrooklynNineNine

```ruby
Faker::TvShows::BrooklynNineNine.character #=> "Jake Peralta"

Faker::TvShows::BrooklynNineNine.quote #=> "Cool, cool, cool, cool, cool. No doubt, no doubt, no doubt."
```
