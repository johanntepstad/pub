# Faker::TvShows::TheOffice

```ruby
Faker::TvShows::TheOffice.character #=> "Michael Scott"

Faker::TvShows::TheOffice.quote #=> "Identity theft is not a joke, Jim! Millions of families suffer every year."
```