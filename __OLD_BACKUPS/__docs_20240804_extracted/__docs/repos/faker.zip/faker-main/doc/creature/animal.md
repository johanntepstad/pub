# Faker::Creature::Animal

```ruby
Faker::Creature::Animal.name #=> "Antelope"
```
