//= link solidus_starter_frontend.js
//= link solidus_starter_frontend.css
//= link tailwind.css
//= link_tree ../../javascript .js
